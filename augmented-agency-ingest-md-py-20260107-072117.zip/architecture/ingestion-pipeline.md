# Continuity Ingestion Pipeline

This document describes how inputs enter the continuity architecture.

The Continuity Ingestion Pipeline is the workflow by which explicit human-generated language inputs (LUIs) and other events are transformed into a continuity-preserving structure suitable for longitudinal re-entry.

This pipeline forms continuity.  
It does not interpret meaning.

---

## Input Sources

Inputs may originate from:
- human language acts (LUIs)
- tools
- agents
- sensors
- systems

All inputs are treated as explicit events, not semantic content.

---

## Ingestion Principles

The pipeline operates under the following constraints:

- no semantic interpretation at ingress
- no goal inference
- no optimization
- no summarization

Ingress converts inputs into non-semantic traces that preserve ordering and identity without extracting meaning.

---

## Data Stores and Boundaries

Ingestion is realized as a **three-store architecture** with strict ownership boundaries:

1) **Capture Store (`iam.db`) — Source-of-Record**
- Append-only capture of raw LUIs/events (plus provenance pointers).
- Adapter-shaped (today: ChatGPT exports; later: other adapters).
- This layer is allowed to be “messy,” but it is authoritative for *what was captured*.

2) **Provenance Store Family (`provdb/*`) — ID ↔ Language + Semantic Coordinates**
- Normalizes captured inputs into a **uniform event record** keyed by stable numeric IDs.
- Owns the mapping: **ID → source language (or span) + provenance**.
- May also store **numeric semantic coordinates** (e.g., embeddings, features) keyed by `(space_id, id)`.
- “Family” means: one authoritative core mapping plus optional derived, versioned views (e.g., FM-optimized chunk stores).

3) **Substrate Store Family (`subdb/*`) — Continuity Geometry + Atlas Structures**
- Semantic-free continuity substrate: ordering coordinates, adjacency, regions, return points, stitching edges.
- May replicate numeric semantic coordinates from `provdb` as **versioned overlays** for performance/portability.
- Substrate correctness must never depend on presence of semantic overlays.

**Join key:** all composition happens by stable IDs (event_id / continuon_id).  
**No semantics cross downward at ingress.** Meaning is used only at re-entry time (IAM/app layer).

---

## Append-Only and Concurrency Contract

To support concurrent processing and auditability, the pipeline enforces:

- **Append-only facts:** raw capture and provenance mappings are never rewritten or deleted.
- **Idempotent builders:** each stage can be re-run without changing existing results.
- **No DROP/overwrite of authoritative structures:** any derived materialization must be either:
  - versioned/append-only (preferred), or
  - explicitly rebuildable cache not used as source-of-truth.

Where revisions are needed (e.g., improved canonicalization), they are represented as new version rows or new views, never in-place mutation.

---

## First Output: LUI Capture Layer (Source-of-Record)

The first invariant output of ingestion is the **LUI Capture Layer**: a persistent, addressable record of explicit events suitable for longitudinal reference.

These records populate the **Continuity Atlas**, which stores continuity structures such as ordering, regions, return points, adjacency, and stitching.

CAP (Continuity Access Protocol) defines the interface and protocol by which these Atlas structures are accessed and navigated.

See: `architecture/lui-capture-layer.md`.

---

## Pipeline Stages

1. **Capture** — explicit event recorded (append-only) into the Capture Store (`iam.db`)
2. **Normalize + ID assignment** — inputs are contracted into a uniform event record in `provdb/*`
3. **Time-indexing** — deterministic ordering coordinates assigned (event stream)
4. **Structural anchoring** — continuity geometry and Atlas structures written into `subdb/*`
5. **Optional interface exposure** — via IAM using CAP

Meaning is not processed at any stage.  
Meaning re-emerges only through human re-entry.

---

## Architectural Boundary

Ingestion is a one-way boundary:

- semantics do not pass downward
- continuity does not infer upward

This boundary is enforced structurally, not by policy.

---

## Relationship to IAM

The Continuity Ingestion Pipeline is not IAM.

- IAM is the conversational interface and thinking support tool.
- The ingestion pipeline operates beneath IAM to provide structural assurance for trust.

IAM coordinates:
- re-entry over continuity geometry (Substrate)
- retrieval/meaning overlays (Provenance semantic spaces)
- capture of new LUIs back into the pipeline

IAM relies on continuity preserved in the Atlas and accessed via CAP, but does not expose the substrate or protocol as user-facing features.

---

## Optional Overlays

Chunking, summaries, and semantic assistance may be computed as overlays, but they are not required for continuity correctness and must remain separable from the LUI Capture Layer and Atlas.

Overlays are versioned and namespaced (e.g., by `space_id` and build version) so multiple semantic coordinate systems can coexist.

---

## Slices and Multiple Substrates

For maximum utility and optimal granularity, the architecture may maintain:

- **Multiple substrates** (e.g., event-level vs continuon-level) over the same ID set.
- **Slices**: derived selections/projections of IDs (and optional cached text spans) optimized for a specific task,
  while preserving stable references back to authoritative provenance and continuity IDs.

All substrates and slices remain addressable via the same IDs and can be composed at the IAM layer.

---

## Atlas Stitching (Internal Name)

Internally, this process may be referred to as **Atlas Stitching**, reflecting the assembly of local continuity records into a coherent Atlas without collapsing meaning.

This name is conceptual and does not imply semantic interpretation.
