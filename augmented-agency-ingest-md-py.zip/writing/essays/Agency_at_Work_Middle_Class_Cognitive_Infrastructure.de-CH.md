<!-- FILENAME: Agency_at_Work_Middle_Class_Cognitive_Infrastructure.de-CH.md -->
<!-- TRANSLATION: lang=de-CH source=Agency_at_Work_Middle_Class_Cognitive_Infrastructure.md canonical=en -->

# Agency bi dr Arbeit: kognitivi Infrastruktur vo dr Mittelschicht

Über langi Ziit isch d Agency vo dr Mittelschicht nöd primär dur Vermöge oder Eigentum abgsicheret worde, sondern dur kognitivi Infrastruktur. Berüef, Institutione und Arbeitsforme händ Strukture bereitgstellt, wo Dänke über d Ziit ermöglich händ. Sie händ Kontext stabilisiert, Erinnerung getragen und Urteil i e Verlauf iigbettet.

Das isch oft nöd als solchi erkannt worde. Es hät sich als Normalität aagfühlt. Arbeit hät d Ziit strukturiert, Projekt händ Gedanke verbunden, Rolle händ Verantwortig definiert. D kognitivi Arbeit, wo das ermöglicht hät, isch im Hintergrund blibe.

---

## Arbeit als Träger vo Kontinuität

Für villi Mänsche hät Arbeit als primäre Träger vo Kontinuität funktioniert. Sie hät e impliziti Reihenfolg vorgäh, Prioritäte gesetzt und Wiederufnahm erleichtert. Gedanke sind nöd im luftleere Ruum entstande; sie sind in Projekt, Friste und soziale Erwartige iigbettet gsi.

Das hät Dänke nöd effizient gmacht, sondern haltbar. Es hät e Verlauf ermöglich, wo Urteil sich entwickle chann. Arbeit isch so zu ere stillschwiegende Infrastruktur worde – nöd weil sie optimal gsi isch, sondern weil sie Bestand ermöglicht hät.

---

## D Erosion vo dere Infrastruktur

Mit dr zunehmende Automatisierig und Flexibilisierig löst sich die Infrastruktur langsam uuf. Arbeit wird fragmentierter, projektbasierter und transaktioneller. Kontext wechselt schnäll. Wiederufnahm wird schwieriger. Gedanke müend sich immer wieder neu positioniere.

Das betrifft nöd nume Produktivität. Es betrifft d Bedingige, unter dene Agency möglich isch. Wenn Kontinuität fehlt, wird Urteil sporadisch. Entscheidunge wirke losglöst, au wenn sie rational begründet sind.

Was verschwindet, isch nöd Arbeit als solchi, sondern ihre Funktion als kognitivi Träger.

---

## D unsichtbari Kosten

D Erosion vo kognitiver Infrastruktur zeigt sich nöd sofort. Am Aafang wirkt Flexibilität befreiend. Weniger Bindig, meh Wahl. Aber über d Ziit sammle sich Kosten aa, wo nöd monetär sind.

Dänke wird kurzatmig. Urteil verliert Tiefi. Bedeutung fragmentiert. Was früehner dur institutionelle Rhythme getragen worde isch, mues jetzt individuell kompensiert werde.

Das isch kei rein persönlechi Herausforderig. Es isch e strukturelli Verschiebig.

---

## Agency ohni Träger

Agency ohni kognitivi Träger isch fragil. Sie hängt vom Moment ab, nöd vom Verlauf. Sie reagiert statt z forme. In so eme Umfeld chönd System, wo kohärenti Antworte liefere, dominant werde – nöd will sie besser dänke, sondern will sie Struktur simulieren.

Aber simulierti Struktur ersetzt kei echte Kontinuität. Sie liefert Orientierung im Moment, aber sie trägt kei Geschichte. Agency wird so zu ere Abfolg vo situative Reaktione.

---

## D Notwendigkeit vo neue Infrastruktur

Wenn d alte kognitivi Infrastruktur erodiert, mues e neue Form entstoh. Nöd als Ersatz für Arbeit, sondern als Ersatz für Kontinuität.

So e Infrastruktur mues nöd effizient sii. Sie mues verlässlich sii. Sie mues Gedanke über d Ziit träge, ohni sie z optimieren. Sie mues Zruggcho ermögliche, ohni Interpretation.

Das isch kei technisches Luxusproblem. Es isch e Voraussetzung defür, dass Agency in ere automatisierte Ziit überhaupt bestoh chann.

---

## Kognitivi Infrastruktur als Voraussetzung für Agency

Agency isch nöd nume e Frag vo Entscheidungsfreiheit. Sie isch e Frag vo Dauer. Ohni d Möglichkeit, zruggzcho, z korrigiere und Bedeutung z akkumulieren, verliert Entscheidungsfreiheit ihri Tiefe.

D Mittelschicht hät historisch vo Infrastruktur profitiert, wo das ermöglicht hät, ohni dass sie explizit benannt worde isch. Mit ihrem Verschwinde wird sichtbar, was immer scho notwendig gsi isch.

Wenn Technologie Agency stärke söll, denn mues sie genau da aasetze. Nöd bi dr Uusfüehrig, sondern bi dr Kontinuität. Nöd bi dr Optimierig, sondern bi dr Bewahrig.

Erst wenn Dänke über d Ziit getragen wird, chann Agency meh sii als e Reaktion. Sie chann wieder Autorschaft werde.
